# Example Skill

这是一个示例技能，用于演示 Skill Manager 的功能。

## 描述

这个技能展示了如何创建一个基本的 Claude Code 技能。

## 使用方法

```bash
/example-skill
```

## 功能

- 演示技能结构
- 提供模板参考
